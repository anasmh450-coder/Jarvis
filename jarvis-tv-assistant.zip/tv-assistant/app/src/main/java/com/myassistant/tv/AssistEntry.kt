package com.myassistant.tv

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.service.voice.VoiceInteractionService
import android.service.voice.VoiceInteractionSession
import android.service.voice.VoiceInteractionSessionService
import android.speech.RecognitionService
import android.speech.SpeechRecognizer

/*
 * These small classes let Android treat Jarvis as the device's assistant.
 * When Jarvis is chosen as the default assistant, the system sends the remote's
 * Assistant button to onShow() below, which opens the Jarvis popup.
 */

class JarvisInteractionService : VoiceInteractionService()

class JarvisSessionService : VoiceInteractionSessionService() {
    override fun onNewSession(args: Bundle?): VoiceInteractionSession = JarvisSession(this)
}

class JarvisSession(ctx: Context) : VoiceInteractionSession(ctx) {
    override fun onShow(args: Bundle?, showFlags: Int) {
        super.onShow(args, showFlags)
        AssistantService.trigger(context.applicationContext)
        hide() // we draw our own popup, so keep the system one invisible
    }
}

/** Required by Android for assistant apps. Jarvis does its own speech recognition, so this stays empty. */
class JarvisRecognitionService : RecognitionService() {
    override fun onStartListening(recognizerIntent: Intent?, listener: RecognitionService.Callback?) {
        listener?.error(SpeechRecognizer.ERROR_CLIENT)
    }

    override fun onCancel(listener: RecognitionService.Callback?) {}

    override fun onStopListening(listener: RecognitionService.Callback?) {}
}

/** Fallback: apps that answer the ASSIST intent show up in the "choose assistant" list. */
class AssistActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AssistantService.trigger(applicationContext)
        finish()
    }
}
