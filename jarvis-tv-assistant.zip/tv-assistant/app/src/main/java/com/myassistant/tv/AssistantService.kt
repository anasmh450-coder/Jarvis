package com.myassistant.tv

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Base64
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.ArrayDeque
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * The brain loop: floating orb + popup + microphone listening + Gemini + talking + TV actions.
 * The remote's assistant button calls AssistantService.trigger() to open the popup and start listening.
 */
class AssistantService : Service(), TextToSpeech.OnInitListener {

    companion object {
        const val ACTION_ACTIVATE = "com.myassistant.tv.ACTIVATE"

        @Volatile
        var running = false

        @Volatile
        private var instance: AssistantService? = null

        private const val TAG = "Jarvis"
        private const val CHANNEL = "jarvis"
        private const val SAMPLE_RATE = 16000
        private const val MAX_STEPS = 5

        /** Called by the remote button handlers. Opens the popup and starts listening. */
        fun trigger(ctx: Context) {
            val s = instance
            if (s != null) {
                s.activate()
                return
            }
            try {
                ctx.startForegroundService(
                    Intent(ctx, AssistantService::class.java).setAction(ACTION_ACTIVATE)
                )
            } catch (e: Exception) {
                Log.w(TAG, "could not start from background: ${e.message}")
            }
        }
    }

    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private lateinit var wm: WindowManager

    // small orb in the corner
    @Volatile
    private var orb: OrbView? = null

    // popup panel (created and removed on the main thread)
    private var popup: View? = null

    @Volatile
    private var popupOrb: OrbView? = null

    @Volatile
    private var captionView: TextView? = null

    @Volatile
    private var popupShown = false
    private val hideRunnable = Runnable { hidePopup() }

    private var tts: TextToSpeech? = null

    @Volatile
    private var ttsReady = false

    @Volatile
    private var busy = false

    @Volatile
    private var followUpUntil = 0L
    private val history = ArrayList<Pair<String, String>>()

    private class Reply(
        val ignore: Boolean,
        val heard: String,
        val say: String,
        val lang: String,
        val actions: JSONArray,
        val cont: Boolean,
        val raw: String
    )

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val wantsActivate = intent?.action == ACTION_ACTIVATE
        if (running) {
            if (wantsActivate) activate()
            return START_STICKY
        }
        running = true
        instance = this

        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Jarvis", NotificationManager.IMPORTANCE_LOW))
        val notif = Notification.Builder(this, CHANNEL)
            .setContentTitle("Jarvis is listening")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(1, notif)
        }

        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        addOrb()
        tts = TextToSpeech(this, this)

        Thread({ micLoop() }, "jarvis-mic").start()
        if (wantsActivate) main.postDelayed({ activate() }, 800)
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        instance = null
        main.removeCallbacks(hideRunnable)
        popup?.let {
            try {
                wm.removeView(it)
            } catch (ignored: Exception) {
            }
        }
        popup = null
        orb?.let {
            try {
                wm.removeView(it)
            } catch (ignored: Exception) {
            }
        }
        orb = null
        tts?.shutdown()
        worker.shutdownNow()
        super.onDestroy()
    }

    // ---------- orb and popup ----------

    private fun setState(s: OrbView.State) {
        orb?.state = s
        popupOrb?.state = s
    }

    private fun setLevel(v: Float) {
        orb?.level = v
        popupOrb?.level = v
    }

    private fun restState() {
        setState(if (popupShown) OrbView.State.LISTENING else OrbView.State.IDLE)
    }

    private fun addOrb() {
        if (!Settings.canDrawOverlays(this)) {
            toast("Allow the floating orb (overlay) first")
            return
        }
        val d = resources.displayMetrics.density
        val size = (140 * d).toInt()
        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.END
        lp.x = (24 * d).toInt()
        lp.y = (16 * d).toInt()
        val view = OrbView(this)
        wm.addView(view, lp)
        orb = view
    }

    /** Main thread only. Shows (or updates) the bottom popup with a big orb and the caption text. */
    private fun showPopup(caption: String) {
        if (!Settings.canDrawOverlays(this)) return
        if (popup == null) {
            val d = resources.displayMetrics.density
            fun dp(v: Int) = (v * d).toInt()

            val root = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(20), dp(14), dp(28), dp(14))
                background = GradientDrawable().apply {
                    cornerRadius = dp(32).toFloat()
                    setColor(0xEE10101E.toInt())
                    setStroke(dp(1), 0x5558C7FF)
                }
            }
            val bigOrb = OrbView(this)
            root.addView(bigOrb, LinearLayout.LayoutParams(dp(110), dp(110)))

            val col = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(10), 0, 0, 0)
            }
            col.addView(TextView(this).apply {
                text = "Jarvis"
                textSize = 13f
                setTextColor(0xFF9AA0B8.toInt())
            })
            val cap = TextView(this).apply {
                textSize = 22f
                setTextColor(Color.WHITE)
                maxLines = 4
            }
            col.addView(cap)
            root.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

            val width = min(dp(720), (resources.displayMetrics.widthPixels * 0.8f).toInt())
            val lp = WindowManager.LayoutParams(
                width, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                PixelFormat.TRANSLUCENT
            )
            lp.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            lp.y = dp(56)

            root.alpha = 0f
            try {
                wm.addView(root, lp)
            } catch (e: Exception) {
                Log.w(TAG, "popup failed: ${e.message}")
                return
            }
            root.animate().alpha(1f).setDuration(200).start()
            popup = root
            popupOrb = bigOrb
            captionView = cap
            popupShown = true
            orb?.visibility = View.INVISIBLE
            bigOrb.state = orb?.state ?: OrbView.State.IDLE
        }
        captionView?.text = caption
    }

    /** Main thread only. */
    private fun hidePopup() {
        val p = popup ?: return
        popup = null
        popupOrb = null
        captionView = null
        popupShown = false
        p.animate().alpha(0f).setDuration(200).withEndAction {
            try {
                wm.removeView(p)
            } catch (ignored: Exception) {
            }
        }.start()
        orb?.visibility = View.VISIBLE
        if (!busy) orb?.state = OrbView.State.IDLE
    }

    private fun scheduleHide(ms: Long) {
        main.removeCallbacks(hideRunnable)
        main.postDelayed(hideRunnable, ms)
    }

    private fun cancelHide() {
        main.removeCallbacks(hideRunnable)
    }

    private fun caption(text: String) {
        main.post { captionView?.text = text }
    }

    /** The remote's assistant button was pressed: pop up and listen, no wake word needed. */
    fun activate() {
        main.post {
            followUpUntil = System.currentTimeMillis() + 20000
            if (busy) {
                // pressing again while he talks cuts him off so you can speak
                tts?.stop()
                if (popup == null) showPopup("...")
                return@post
            }
            showPopup("Listening...")
            setState(OrbView.State.LISTENING)
            scheduleHide(9000)
        }
    }

    private fun toast(msg: String) {
        main.post { Toast.makeText(applicationContext, msg, Toast.LENGTH_LONG).show() }
    }

    // ---------- talking ----------

    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
        if (ttsReady) {
            // short hello so you know it works
            busy = true
            setState(OrbView.State.SPEAKING)
            tts?.speak("Jarvis is ready.", TextToSpeech.QUEUE_FLUSH, null, "hello")
            main.postDelayed({
                busy = false
                restState()
            }, 2500)
        }
    }

    private fun speakBlocking(text: String, lang: String) {
        val engine = tts
        if (engine == null || !ttsReady || text.isBlank()) return
        val latch = CountDownLatch(1)
        engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                setState(OrbView.State.SPEAKING)
            }

            override fun onDone(utteranceId: String?) {
                latch.countDown()
            }

            override fun onStop(utteranceId: String?, interrupted: Boolean) {
                latch.countDown()
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                latch.countDown()
            }
        })
        try {
            val loc = Locale.forLanguageTag(lang)
            if (engine.isLanguageAvailable(loc) >= TextToSpeech.LANG_AVAILABLE) engine.setLanguage(loc)
        } catch (ignored: Exception) {
        }
        setState(OrbView.State.SPEAKING)
        engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, "u" + System.nanoTime())
        latch.await(60, TimeUnit.SECONDS)
    }

    // ---------- listening ----------

    private fun micLoop() {
        val minBuf = AudioRecord.getMinBufferSize(
            SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        val rec: AudioRecord
        try {
            rec = AudioRecord(
                MediaRecorder.AudioSource.MIC, SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
                max(minBuf, SAMPLE_RATE)
            )
        } catch (e: Exception) {
            toast("Microphone error: ${e.message}")
            main.post { stopSelf() }
            return
        }
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            toast("No microphone available on this device")
            main.post { stopSelf() }
            return
        }
        rec.startRecording()

        val frame = ShortArray(320) // 20 ms
        val pre = ArrayDeque<ShortArray>()
        var utter: ByteArrayOutputStream? = null
        var startRun = 0
        var voicedFrames = 0
        var silentFrames = 0
        var total = 0
        var noise = 400f

        while (running) {
            val n = rec.read(frame, 0, frame.size)
            if (n <= 0) continue

            if (busy) {
                // don't listen to ourselves
                setLevel(0f)
                pre.clear()
                utter = null
                startRun = 0
                continue
            }

            var sum = 0.0
            for (i in 0 until n) sum += frame[i].toDouble() * frame[i].toDouble()
            val rms = sqrt(sum / n).toFloat()
            val threshold = max(1100f, noise * 3.2f)
            val voiced = rms > threshold
            setLevel(min(1f, rms / 7000f))

            val cur = utter
            if (cur == null) {
                if (!voiced) noise = noise * 0.97f + rms * 0.03f
                pre.addLast(frame.copyOf(n))
                if (pre.size > 15) pre.removeFirst()
                startRun = if (voiced) startRun + 1 else 0
                if (startRun >= 4) {
                    val buf = ByteArrayOutputStream()
                    for (f in pre) writeShorts(buf, f, f.size)
                    pre.clear()
                    utter = buf
                    voicedFrames = startRun
                    silentFrames = 0
                    total = 0
                    cancelHide()
                    setState(OrbView.State.LISTENING)
                }
            } else {
                writeShorts(cur, frame, n)
                total++
                if (voiced) {
                    voicedFrames++
                    silentFrames = 0
                } else {
                    silentFrames++
                }
                if (silentFrames >= 45 || total >= 750) { // 0.9 s of quiet, or 15 s max
                    val data = cur.toByteArray()
                    utter = null
                    startRun = 0
                    if (voicedFrames >= 20) {
                        busy = true
                        setState(OrbView.State.THINKING)
                        caption("Thinking...")
                        worker.execute { runTurn(data) }
                    } else {
                        restState()
                        if (popupShown) scheduleHide(5000)
                    }
                }
            }
        }
        try {
            rec.stop()
        } catch (ignored: Exception) {
        }
        rec.release()
    }

    private fun writeShorts(out: ByteArrayOutputStream, f: ShortArray, n: Int) {
        val b = ByteArray(n * 2)
        for (i in 0 until n) {
            val v = f[i].toInt()
            b[2 * i] = (v and 0xFF).toByte()
            b[2 * i + 1] = ((v shr 8) and 0xFF).toByte()
        }
        out.write(b, 0, b.size)
    }

    private fun wav(pcm: ByteArray): ByteArray {
        val ch = 1
        val bits = 16
        val bb = ByteBuffer.allocate(44 + pcm.size).order(ByteOrder.LITTLE_ENDIAN)
        bb.put("RIFF".toByteArray())
        bb.putInt(36 + pcm.size)
        bb.put("WAVE".toByteArray())
        bb.put("fmt ".toByteArray())
        bb.putInt(16)
        bb.putShort(1)
        bb.putShort(ch.toShort())
        bb.putInt(SAMPLE_RATE)
        bb.putInt(SAMPLE_RATE * ch * bits / 8)
        bb.putShort((ch * bits / 8).toShort())
        bb.putShort(bits.toShort())
        bb.put("data".toByteArray())
        bb.putInt(pcm.size)
        bb.put(pcm)
        return bb.array()
    }

    private fun b64(bytes: ByteArray): String = Base64.encodeToString(bytes, Base64.NO_WRAP)

    // ---------- one conversation turn ----------

    private fun systemPrompt(apps: Collection<String>): String = """
You are "Jarvis", a powerful, friendly voice assistant living on the user's Android TV. You hear the user through the TV microphone (the audio is attached to their message) and you talk back through the TV speakers. You can control the TV.

WAKE WORD: The user calls you by saying "Jarvis", or by pressing the assistant button on the remote (then followUp is true). Each message includes "followUp: true/false". If followUp is false and the audio does not clearly address you (no "Jarvis"), or it is TV sound, background noise or silence, answer with {"ignore": true} and nothing else. If followUp is true, treat any speech aimed at you as a request.

Reply with ONLY one JSON object, no markdown, no extra text:
{"ignore": false, "heard": "what the user said", "say": "what you say out loud", "lang": "en", "actions": [], "continue": false}

- say: short and natural (one or two sentences) unless the user asks for detail. Same language the user spoke. No emojis, no markdown, no lists.
- lang: BCP-47 code of the language of "say" (en, fr, ar, es...).
- actions: executed in order. Allowed types:
  {"type":"open_app","name":"YouTube"}  (pick a name from the installed apps list)
  {"type":"youtube_search","query":"..."}
  {"type":"open_url","url":"https://..."}
  {"type":"key","key":"up|down|left|right|select|back|home|recents|notifications"}
  {"type":"click_text","text":"text of a visible item"}
  {"type":"scroll","direction":"up|down"}
  {"type":"set_text","text":"..."}  (types into a text field)
  {"type":"volume","direction":"up|down|mute","steps":3}
  {"type":"media","action":"play_pause|next|previous"}
- continue: set true when you must SEE the screen to finish (to read it, or after an action to click the next thing). You will then automatically receive a fresh screenshot plus the visible text and the results of your actions. Set false when the task is done. To just look at the screen, use "actions": [] with "continue": true and "say": "".
- Questions: answer from your knowledge, and use Google Search for anything current (news, scores, weather, prices).
- Never say you did something unless you did it with an action. If an action result says it failed, tell the user honestly.
- Protected video (Netflix etc.) may appear black in screenshots; the visible text list still works.

Apps installed on this TV: ${apps.joinToString(", ")}
""".trimIndent()

    private fun runTurn(pcm: ByteArray) {
        var spoke = false
        try {
            val key = Config.apiKey(this)
            if (key.isBlank()) {
                main.post { showPopup("I need a Gemini API key. Add it in the Jarvis app.") }
                speakBlocking("I need a Gemini API key. Please add it in the app.", "en")
                return
            }
            val runner = ActionRunner(this)
            val system = systemPrompt(runner.installedApps().keys.take(80))
            val followUp = System.currentTimeMillis() < followUpUntil

            val contents = JSONArray()
            for ((h, s) in history.takeLast(6)) {
                contents.put(GeminiClient.textTurn("user", h))
                contents.put(GeminiClient.textTurn("model", s))
            }
            val first = JSONArray()
                .put(JSONObject().put("inlineData", JSONObject().put("mimeType", "audio/wav").put("data", b64(wav(pcm)))))
                .put(JSONObject().put("text", "followUp: $followUp"))
            contents.put(JSONObject().put("role", "user").put("parts", first))

            var heard = ""
            var lastSay = ""
            var step = 0
            while (step < MAX_STEPS) {
                step++
                val raw = GeminiClient.generate(key, system, contents)
                val reply = parse(raw)
                if (reply.ignore) break
                if (reply.heard.isNotBlank()) heard = reply.heard
                contents.put(GeminiClient.textTurn("model", reply.raw))

                // he is answering, so show the popup (also when you used the wake word)
                val shown = if (reply.say.isNotBlank()) reply.say else "Working on it..."
                main.post {
                    cancelHide()
                    showPopup(shown)
                }

                setState(OrbView.State.THINKING)
                val report = if (reply.actions.length() > 0) runner.run(reply.actions) else ""

                if (reply.say.isNotBlank()) {
                    speakBlocking(reply.say, reply.lang)
                    spoke = true
                    lastSay = reply.say
                }
                if (!reply.cont) break

                // look at the screen and let Gemini continue
                setState(OrbView.State.THINKING)
                Thread.sleep(1500)
                val a11y = TvAccessibilityService.instance
                val parts = JSONArray()
                if (a11y == null) {
                    parts.put(JSONObject().put("text", "Accessibility service is not enabled, so I cannot see or control the screen. Tell the user to enable it in the Jarvis app."))
                } else {
                    val shot = a11y.screenshotJpeg()
                    if (shot != null) {
                        parts.put(JSONObject().put("inlineData", JSONObject().put("mimeType", "image/jpeg").put("data", b64(shot))))
                    }
                    val text = a11y.screenText()
                    parts.put(
                        JSONObject().put(
                            "text",
                            "Action results: ${report.ifBlank { "none" }}. Visible screen text: ${text.ifBlank { "(none)" }}. " +
                                "Continue the user's request. followUp: true"
                        )
                    )
                }
                contents.put(JSONObject().put("role", "user").put("parts", parts))
            }

            if (spoke) {
                history.add(Pair(heard.ifBlank { "(voice request)" }, lastSay))
                while (history.size > 6) history.removeAt(0)
            }
        } catch (e: Exception) {
            Log.e(TAG, "turn failed", e)
            val msg = e.message ?: ""
            toast("Jarvis error: ${msg.take(160)}")
            main.post { if (popupShown) captionView?.text = "Sorry, I could not do that." }
            speakBlocking("Sorry, I could not do that.", "en")
            spoke = true
        } finally {
            if (spoke) followUpUntil = System.currentTimeMillis() + 9000
            main.postDelayed({
                busy = false
                restState()
                if (popupShown) scheduleHide(6000)
            }, 500)
        }
    }

    private fun parse(raw: String): Reply {
        val s = raw.indexOf('{')
        val e = raw.lastIndexOf('}')
        if (s >= 0 && e > s) {
            try {
                val j = JSONObject(raw.substring(s, e + 1))
                return Reply(
                    j.optBoolean("ignore", false),
                    j.optString("heard"),
                    j.optString("say"),
                    j.optString("lang", "en").ifBlank { "en" },
                    j.optJSONArray("actions") ?: JSONArray(),
                    j.optBoolean("continue", false),
                    raw
                )
            } catch (ignored: Exception) {
            }
        }
        return Reply(false, "", raw.trim(), "en", JSONArray(), false, raw)
    }
}
