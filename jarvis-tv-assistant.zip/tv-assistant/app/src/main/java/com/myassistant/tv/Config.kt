package com.myassistant.tv

import android.content.Context

object Config {
    const val MODEL = "gemini-2.5-flash"

    private const val PREFS = "jarvis_prefs"
    private const val KEY_API = "api_key"

    /** Key typed in the app wins; otherwise the one baked in at build time from the GitHub secret. */
    fun apiKey(ctx: Context): String {
        val saved = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_API, null)
        return if (!saved.isNullOrBlank()) saved.trim() else BuildConfig.GEMINI_API_KEY
    }

    fun saveApiKey(ctx: Context, key: String) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_API, key.trim()).apply()
    }

    fun hasBuiltInKey(): Boolean = BuildConfig.GEMINI_API_KEY.isNotBlank()
}
