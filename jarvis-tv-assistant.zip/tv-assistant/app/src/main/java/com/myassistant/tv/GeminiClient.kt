package com.myassistant.tv

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object GeminiClient {

    class GeminiException(message: String) : Exception(message)

    fun textTurn(role: String, text: String): JSONObject =
        JSONObject()
            .put("role", role)
            .put("parts", JSONArray().put(JSONObject().put("text", text)))

    /**
     * Sends the conversation to Gemini and returns the raw text answer.
     * Google Search grounding is on by default so the assistant can answer current questions.
     * If the request is rejected with a 400 (for example the tool is not allowed), it retries once without search.
     */
    fun generate(apiKey: String, system: String, contents: JSONArray, useSearch: Boolean = true): String {
        try {
            return call(apiKey, system, contents, useSearch)
        } catch (e: GeminiException) {
            if (useSearch && e.message?.startsWith("HTTP 400") == true) {
                return call(apiKey, system, contents, false)
            }
            throw e
        }
    }

    private fun call(apiKey: String, system: String, contents: JSONArray, useSearch: Boolean): String {
        val body = JSONObject()
            .put(
                "systemInstruction",
                JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system)))
            )
            .put("contents", contents)
            .put("generationConfig", JSONObject().put("temperature", 0.5))
        if (useSearch) {
            body.put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))
        }

        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/${Config.MODEL}:generateContent")
        val conn = url.openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 15000
            conn.readTimeout = 60000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("x-goog-api-key", apiKey)
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            if (code !in 200..299) throw GeminiException("HTTP $code: ${text.take(400)}")

            val parts = JSONObject(text)
                .optJSONArray("candidates")
                ?.optJSONObject(0)
                ?.optJSONObject("content")
                ?.optJSONArray("parts")
                ?: throw GeminiException("Empty answer from Gemini")

            val sb = StringBuilder()
            for (i in 0 until parts.length()) {
                sb.append(parts.getJSONObject(i).optString("text"))
            }
            return sb.toString()
        } finally {
            conn.disconnect()
        }
    }
}
