package com.myassistant.tv

import android.accessibilityservice.AccessibilityService
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.net.Uri
import android.view.KeyEvent
import android.view.View
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder

/** Carries out the actions Gemini asks for. Always call from a background thread. */
class ActionRunner(private val ctx: Context) {

    private val pm: PackageManager = ctx.packageManager

    /** label -> package name for every app you can launch on this TV */
    fun installedApps(): Map<String, String> {
        val out = LinkedHashMap<String, String>()
        for (cat in listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)) {
            val intent = Intent(Intent.ACTION_MAIN).addCategory(cat)
            for (ri in pm.queryIntentActivities(intent, 0)) {
                val pkg = ri.activityInfo.packageName
                if (pkg == ctx.packageName || out.containsValue(pkg)) continue
                out[ri.loadLabel(pm).toString()] = pkg
            }
        }
        return out
    }

    /** Runs the actions in order and returns a short report for Gemini. */
    fun run(actions: JSONArray): String {
        val notes = ArrayList<String>()
        for (i in 0 until actions.length()) {
            val a = actions.optJSONObject(i) ?: continue
            val note = try {
                one(a)
            } catch (e: Exception) {
                "${a.optString("type")} failed: ${e.message}"
            }
            notes.add(note)
            Thread.sleep(700)
        }
        return notes.joinToString("; ")
    }

    private fun one(a: JSONObject): String {
        return when (a.optString("type")) {
            "open_app" -> openApp(a.optString("name"))
            "youtube_search" -> youtubeSearch(a.optString("query"))
            "open_url" -> openUrl(a.optString("url"))
            "key" -> key(a.optString("key"))
            "click_text" -> withA11y("click \"${a.optString("text")}\"") { it.clickText(a.optString("text")) }
            "scroll" -> withA11y("scroll") { it.scroll(a.optString("direction").lowercase() != "up") }
            "set_text" -> withA11y("type text") { it.setText(a.optString("text")) }
            "volume" -> volume(a.optString("direction"), a.optInt("steps", 3))
            "media" -> media(a.optString("action"))
            else -> "unknown action ${a.optString("type")}"
        }
    }

    private fun withA11y(label: String, block: (TvAccessibilityService) -> Boolean): String {
        val s = TvAccessibilityService.instance
            ?: return "$label failed: accessibility service is not enabled"
        return "$label " + if (block(s)) "ok" else "failed"
    }

    // ---------- apps and links ----------

    private fun norm(s: String) = s.lowercase().filter { it.isLetterOrDigit() }

    private fun openApp(name: String): String {
        val wanted = norm(name)
        if (wanted.isEmpty()) return "open app failed: no name"
        var bestPkg: String? = null
        var bestLabel = ""
        var bestScore = 0
        for ((label, pkg) in installedApps()) {
            val l = norm(label)
            val score = when {
                l == wanted -> 4
                l.startsWith(wanted) || wanted.startsWith(l) -> 3
                l.contains(wanted) || wanted.contains(l) -> 2
                else -> 0
            }
            if (score > bestScore) {
                bestScore = score
                bestPkg = pkg
                bestLabel = label
            }
        }
        val pkg = bestPkg ?: return "open $name failed: app not found"
        val intent = pm.getLeanbackLaunchIntentForPackage(pkg)
            ?: pm.getLaunchIntentForPackage(pkg)
            ?: return "open $bestLabel failed: cannot launch"
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(intent)
        return "opened $bestLabel"
    }

    private fun youtubeSearch(query: String): String {
        if (query.isBlank()) return "youtube search failed: empty query"
        val uri = Uri.parse("https://www.youtube.com/results?search_query=" + URLEncoder.encode(query, "UTF-8"))
        for (p in listOf("com.google.android.youtube.tv", "com.google.android.youtube", null)) {
            try {
                val i = Intent(Intent.ACTION_VIEW, uri).setPackage(p).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                ctx.startActivity(i)
                return "youtube search for \"$query\" ok"
            } catch (ignored: ActivityNotFoundException) {
            }
        }
        return "youtube search failed: no app can open it"
    }

    private fun openUrl(url: String): String {
        if (url.isBlank()) return "open url failed: empty"
        return try {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            "opened $url"
        } catch (ignored: ActivityNotFoundException) {
            "open url failed: no app can open $url"
        }
    }

    // ---------- remote-control keys ----------

    private fun key(k: String): String {
        val s = TvAccessibilityService.instance
            ?: return "key $k failed: accessibility service is not enabled"
        val ok = when (k.lowercase()) {
            "up" -> s.moveFocus(View.FOCUS_UP)
            "down" -> s.moveFocus(View.FOCUS_DOWN)
            "left" -> s.moveFocus(View.FOCUS_LEFT)
            "right" -> s.moveFocus(View.FOCUS_RIGHT)
            "select", "ok", "enter" -> s.select()
            "back" -> s.global(AccessibilityService.GLOBAL_ACTION_BACK)
            "home" -> s.global(AccessibilityService.GLOBAL_ACTION_HOME)
            "recents" -> s.global(AccessibilityService.GLOBAL_ACTION_RECENTS)
            "notifications" -> s.global(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS)
            else -> false
        }
        return "key $k " + if (ok) "ok" else "failed"
    }

    // ---------- sound and media ----------

    private fun volume(direction: String, steps: Int): String {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val n = steps.coerceIn(1, 15)
        when (direction.lowercase()) {
            "up" -> repeat(n) {
                am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
            }
            "down" -> repeat(n) {
                am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
            }
            "mute" -> am.adjustStreamVolume(
                AudioManager.STREAM_MUSIC,
                AudioManager.ADJUST_TOGGLE_MUTE,
                AudioManager.FLAG_SHOW_UI
            )
            else -> return "volume failed: unknown direction"
        }
        return "volume $direction ok"
    }

    private fun media(action: String): String {
        val code = when (action.lowercase()) {
            "play_pause", "play", "pause" -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
            "next" -> KeyEvent.KEYCODE_MEDIA_NEXT
            "previous" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
            else -> return "media failed: unknown action"
        }
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
        return "media $action ok"
    }
}
