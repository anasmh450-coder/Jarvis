package com.myassistant.tv

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.view.View
import java.util.Random
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * A glowing 3D particle globe: dots on a sphere, thin links between neighbours and bright arcs,
 * all rotating. It spins slowly when idle, swells and gets restless with your voice while
 * listening, shows an orbiting comet ring while thinking and pulses (pink) while the assistant talks.
 */
class OrbView(context: Context) : View(context) {

    enum class State { IDLE, LISTENING, THINKING, SPEAKING }

    @Volatile var state: State = State.IDLE

    /** Microphone loudness from 0 to 1. */
    @Volatile var level: Float = 0f

    // ---------- geometry (built once) ----------
    private val n = 300
    private val px = FloatArray(n)
    private val py = FloatArray(n)
    private val pz = FloatArray(n)
    private val phase = FloatArray(n)

    private var edgeA = IntArray(0)
    private var edgeB = IntArray(0)

    private val arcCount = 18
    private val arcSeg = 24
    private val arcA = IntArray(arcCount)
    private val arcB = IntArray(arcCount)
    private val arcBulge = FloatArray(arcCount)
    private val arcPts = Array(arcCount) { FloatArray((arcSeg + 1) * 3) } // base positions on the unit sphere

    private val dustN = 140
    private val dx = FloatArray(dustN)
    private val dy = FloatArray(dustN)
    private val dz = FloatArray(dustN)

    private val ringN = 80

    // ---------- per-frame buffers (no allocation while drawing) ----------
    private val sx = FloatArray(n)
    private val sy = FloatArray(n)
    private val sz = FloatArray(n)
    private val tx = FloatArray(arcSeg + 1)
    private val ty = FloatArray(arcSeg + 1)
    private val tz = FloatArray(arcSeg + 1)
    private val lineBuf = Array(3) { FloatArray(edgeCapacity() * 4) }
    private val lineCnt = IntArray(3)
    private val arcBuf = Array(3) { FloatArray(arcCount * arcSeg * 4) }
    private val arcCnt = IntArray(3)
    private val dotBuf = Array(4) { FloatArray(n * 2 + dustN * 2 + ringN * 2) }
    private val dotCnt = IntArray(4)

    private fun edgeCapacity() = n * 4

    // ---------- paints ----------
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND }
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND }
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG)

    // ---------- animation state ----------
    private var amp = 0f
    private var speakMix = 0f
    private var thinkMix = 0f
    private var spin = 0f
    private var ringAngle = 0f
    private var lastNs = System.nanoTime()
    private val t0 = lastNs

    // colours: listening / idle (cyan-blue) and speaking (pink-violet)
    private val lineL = intArrayOf(60, 160, 255)
    private val dotL = intArrayOf(175, 232, 255)
    private val arcL = intArrayOf(150, 228, 255)
    private val glowL = intArrayOf(40, 110, 255)
    private val lineS = intArrayOf(205, 80, 235)
    private val dotS = intArrayOf(255, 175, 238)
    private val arcS = intArrayOf(255, 165, 228)
    private val glowS = intArrayOf(175, 60, 255)

    init {
        val rnd = Random(7)

        // evenly spread points on a sphere (golden spiral)
        for (i in 0 until n) {
            val k = i + 0.5f
            val ph = acos(1f - 2f * k / n)
            val th = (PI * (1.0 + sqrt(5.0)) * k).toFloat()
            px[i] = (cos(th) * sin(ph))
            py[i] = cos(ph)
            pz[i] = (sin(th) * sin(ph))
            phase[i] = rnd.nextFloat() * (2f * PI).toFloat()
        }

        // link each point to its 3 nearest neighbours
        val ea = ArrayList<Int>()
        val eb = ArrayList<Int>()
        val seen = HashSet<Long>()
        val dist = FloatArray(n)
        for (a in 0 until n) {
            for (b in 0 until n) {
                val ddx = px[a] - px[b]
                val ddy = py[a] - py[b]
                val ddz = pz[a] - pz[b]
                dist[b] = if (a == b) 9f else sqrt(ddx * ddx + ddy * ddy + ddz * ddz)
            }
            repeat(3) {
                var best = -1
                var bd = 9f
                for (b in 0 until n) if (dist[b] < bd) {
                    bd = dist[b]
                    best = b
                }
                if (best >= 0 && bd < 0.34f) {
                    val lo = min(a, best)
                    val hi = max(a, best)
                    if (seen.add(lo.toLong() * 100000L + hi)) {
                        ea.add(lo)
                        eb.add(hi)
                    }
                }
                if (best >= 0) dist[best] = 9f
            }
        }
        edgeA = ea.toIntArray()
        edgeB = eb.toIntArray()

        // long bright arcs that lift off the surface
        var made = 0
        while (made < arcCount) {
            val a = rnd.nextInt(n)
            val b = rnd.nextInt(n)
            val dot = (px[a] * px[b] + py[a] * py[b] + pz[a] * pz[b]).coerceIn(-1f, 1f)
            val ang = acos(dot)
            if (ang < 1.0f || ang > 2.3f) continue
            arcA[made] = a
            arcB[made] = b
            arcBulge[made] = 0.10f + rnd.nextFloat() * 0.12f
            val om = ang
            val so = sin(om)
            for (s in 0..arcSeg) {
                val t = s.toFloat() / arcSeg
                val w0 = sin((1 - t) * om) / so
                val w1 = sin(t * om) / so
                val o = s * 3
                arcPts[made][o] = w0 * px[a] + w1 * px[b]
                arcPts[made][o + 1] = w0 * py[a] + w1 * py[b]
                arcPts[made][o + 2] = w0 * pz[a] + w1 * pz[b]
            }
            made++
        }

        // faint dust floating around the globe
        for (i in 0 until dustN) {
            var x: Float
            var y: Float
            var z: Float
            var l: Float
            do {
                x = rnd.nextFloat() * 2f - 1f
                y = rnd.nextFloat() * 2f - 1f
                z = rnd.nextFloat() * 2f - 1f
                l = sqrt(x * x + y * y + z * z)
            } while (l < 0.2f || l > 1f)
            val r = 1.03f + rnd.nextFloat() * 0.29f
            dx[i] = x / l * r
            dy[i] = y / l * r
            dz[i] = z / l * r
        }
    }

    private fun mixC(a: IntArray, b: IntArray, f: Float, k: Float, i: Int): Int {
        val v = (a[i] + (b[i] - a[i]) * f) * k
        return v.toInt().coerceIn(0, 255)
    }

    private fun setColor(p: Paint, a: IntArray, b: IntArray, f: Float, k: Float, alpha: Float) {
        p.color = Color.argb(
            (alpha * 255f).toInt().coerceIn(0, 255),
            mixC(a, b, f, k, 0), mixC(a, b, f, k, 1), mixC(a, b, f, k, 2)
        )
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) {
            postInvalidateOnAnimation()
            return
        }

        val now = System.nanoTime()
        val dt = min(0.05f, (now - lastNs) / 1_000_000_000f)
        lastNs = now
        val t = (now - t0) / 1_000_000_000f
        val st = state

        // smooth state blending
        val target = when (st) {
            State.IDLE -> 0f
            State.LISTENING -> min(1f, level * 1.8f)
            State.THINKING -> 0.15f
            State.SPEAKING -> 0.35f + 0.55f * abs(sin(t * 6.8f) * cos(t * 2.9f + 0.7f))
        }
        amp += (target - amp) * 0.18f
        speakMix += ((if (st == State.SPEAKING) 1f else 0f) - speakMix) * 0.08f
        thinkMix += ((if (st == State.THINKING) 1f else 0f) - thinkMix) * 0.10f

        val spinSpeed = 0.35f + 0.9f * amp + 1.5f * thinkMix
        val twoPi = (2.0 * PI).toFloat()
        spin = (spin + dt * spinSpeed) % twoPi
        ringAngle = (ringAngle + dt * 3.0f) % twoPi

        val cx = w / 2f
        val cy = h / 2f
        val base = min(w, h) * 0.30f
        val r = base * (1f + 0.22f * amp + 0.03f * sin(t * 1.6f))
        val disp = 0.03f + 0.12f * amp
        val bright = 0.80f + 0.30f * amp

        val tilt = 0.40f
        val cyaw = cos(spin)
        val syaw = sin(spin)
        val ctil = cos(tilt)
        val stil = sin(tilt)

        // ----- soft dark scrim + glow so the globe reads on bright video -----
        val glowR = min(w, h) / 2f
        val gAlpha = 0.16f + 0.14f * amp
        glowPaint.shader = RadialGradient(
            cx, cy, glowR,
            intArrayOf(
                Color.argb((gAlpha * 255).toInt(), mixC(glowL, glowS, speakMix, 1f, 0), mixC(glowL, glowS, speakMix, 1f, 1), mixC(glowL, glowS, speakMix, 1f, 2)),
                Color.argb(0, mixC(glowL, glowS, speakMix, 1f, 0), mixC(glowL, glowS, speakMix, 1f, 1), mixC(glowL, glowS, speakMix, 1f, 2))
            ),
            floatArrayOf(0.25f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, glowR, glowPaint)
        glowPaint.shader = null
        glowPaint.color = Color.argb(70, 4, 4, 12)
        canvas.drawCircle(cx, cy, r * 1.02f, glowPaint)

        // ----- project the points -----
        for (i in 0 until n) {
            val dd = 1f + disp * sin(t * 2.3f + phase[i])
            val x = px[i] * dd
            val y = py[i] * dd
            val z = pz[i] * dd
            val x1 = x * cyaw + z * syaw
            val z1 = -x * syaw + z * cyaw
            val y2 = y * ctil - z1 * stil
            val z2 = y * stil + z1 * ctil
            val s = 1f + 0.14f * z2
            sx[i] = cx + x1 * r * s
            sy[i] = cy - y2 * r * s
            sz[i] = z2
        }

        lineCnt.fill(0)
        arcCnt.fill(0)
        dotCnt.fill(0)

        // links, in 3 depth buckets (back / middle / front)
        for (e in edgeA.indices) {
            val a = edgeA[e]
            val b = edgeB[e]
            val z = (sz[a] + sz[b]) * 0.5f
            val bk = if (z < -0.33f) 0 else if (z < 0.33f) 1 else 2
            val buf = lineBuf[bk]
            val o = lineCnt[bk]
            if (o + 4 > buf.size) continue
            buf[o] = sx[a]; buf[o + 1] = sy[a]; buf[o + 2] = sx[b]; buf[o + 3] = sy[b]
            lineCnt[bk] = o + 4
        }

        // arcs
        for (q in 0 until arcCount) {
            val pts = arcPts[q]
            for (s in 0..arcSeg) {
                val tt = s.toFloat() / arcSeg
                val lift = 1f + arcBulge[q] * sin(PI.toFloat() * tt) +
                    disp * 0.6f * sin(t * 2f + tt * 6f + q)
                val x = pts[s * 3] * lift
                val y = pts[s * 3 + 1] * lift
                val z = pts[s * 3 + 2] * lift
                val x1 = x * cyaw + z * syaw
                val z1 = -x * syaw + z * cyaw
                val y2 = y * ctil - z1 * stil
                val z2 = y * stil + z1 * ctil
                val sc = 1f + 0.14f * z2
                tx[s] = cx + x1 * r * sc
                ty[s] = cy - y2 * r * sc
                tz[s] = z2
            }
            for (s in 0 until arcSeg) {
                val z = (tz[s] + tz[s + 1]) * 0.5f
                val bk = if (z < -0.33f) 0 else if (z < 0.33f) 1 else 2
                val buf = arcBuf[bk]
                val o = arcCnt[bk]
                if (o + 4 > buf.size) continue
                buf[o] = tx[s]; buf[o + 1] = ty[s]; buf[o + 2] = tx[s + 1]; buf[o + 3] = ty[s + 1]
                arcCnt[bk] = o + 4
            }
        }

        // dots in 4 depth buckets (dust and points)
        for (i in 0 until dustN) {
            val x = dx[i] * (1f + 0.5f * disp)
            val y = dy[i] * (1f + 0.5f * disp)
            val z = dz[i] * (1f + 0.5f * disp)
            val yw = spin * 0.6f
            val x1 = x * cos(yw) + z * sin(yw)
            val z1 = -x * sin(yw) + z * cos(yw)
            val y2 = y * ctil - z1 * stil
            val z2 = y * stil + z1 * ctil
            val sc = 1f + 0.14f * z2
            addDot(0, cx + x1 * r * sc, cy - y2 * r * sc)
        }
        for (i in 0 until n) {
            val bk = if (sz[i] < -0.4f) 0 else if (sz[i] < 0.1f) 1 else if (sz[i] < 0.6f) 2 else 3
            addDot(if (bk == 0) 0 else bk, sx[i], sy[i])
        }

        // ----- draw: back to front -----
        val lw = max(1f, r * 0.0075f)
        val aw = max(1.3f, r * 0.012f)
        val lineAlpha = floatArrayOf(0.20f, 0.42f, 0.70f)
        val arcAlpha = floatArrayOf(0.30f, 0.65f, 1.00f)
        for (bk in 0..2) {
            linePaint.strokeWidth = lw
            setColor(linePaint, lineL, lineS, speakMix, 1f, lineAlpha[bk] * bright)
            canvas.drawLines(lineBuf[bk], 0, lineCnt[bk], linePaint)
            linePaint.strokeWidth = aw
            setColor(linePaint, arcL, arcS, speakMix, 1f, arcAlpha[bk] * bright)
            canvas.drawLines(arcBuf[bk], 0, arcCnt[bk], linePaint)
            if (bk == 0) drawDots(canvas, 0, r * 0.012f, 0.35f * bright)
            if (bk == 1) drawDots(canvas, 1, r * 0.015f, 0.65f * bright)
        }
        drawDots(canvas, 2, r * 0.020f, 0.90f * bright)
        drawDots(canvas, 3, r * 0.026f, 1.00f * bright)

        // ----- thinking: a comet of particles orbiting the globe -----
        if (thinkMix > 0.02f) {
            val rt = Math.toRadians(-24.0)
            val ct = cos(rt).toFloat()
            val stt = sin(rt).toFloat()
            for (j in 0 until ringN) {
                val ang = (2.0 * PI * j / ringN).toFloat()
                val x = cos(ang) * 1.38f
                val z = sin(ang) * 1.38f
                val y1 = -z * stt
                val z1 = z * ct
                val sc = 1f + 0.14f * z1
                var tail = (ringAngle - ang) % (2f * PI.toFloat())
                if (tail < 0f) tail += 2f * PI.toFloat()
                tail /= (2f * PI.toFloat())
                val k = max(0.25f, 1f - tail * 0.9f) * (0.6f + 0.4f * (z1 + 1.5f) / 3f) * thinkMix
                val rad = r * (0.010f + 0.022f * max(0f, 1f - tail * 2.5f))
                setColor(dotPaint, dotL, dotS, speakMix, 1f, min(1f, k))
                dotPaint.strokeWidth = rad * 2f
                canvas.drawPoint(cx + x * r * sc, cy - (y1 * 1f) * r * sc, dotPaint)
            }
        }

        postInvalidateOnAnimation()
    }

    private fun addDot(bucket: Int, x: Float, y: Float) {
        val buf = dotBuf[bucket]
        val o = dotCnt[bucket]
        if (o + 2 > buf.size) return
        buf[o] = x
        buf[o + 1] = y
        dotCnt[bucket] = o + 2
    }

    private fun drawDots(canvas: Canvas, bucket: Int, radius: Float, alpha: Float) {
        if (dotCnt[bucket] == 0) return
        dotPaint.strokeWidth = max(1.6f, radius * 2f)
        setColor(dotPaint, dotL, dotS, speakMix, 1f, alpha)
        canvas.drawPoints(dotBuf[bucket], 0, dotCnt[bucket], dotPaint)
    }
}
