package com.myassistant.tv

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.graphics.Bitmap
import android.os.Build
import android.os.Bundle
import android.view.Display
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.io.ByteArrayOutputStream
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.math.max
import kotlin.math.min

/**
 * This is how Jarvis controls the TV: moving focus, clicking, scrolling, typing,
 * reading the screen text and taking screenshots.
 */
class TvAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: TvAccessibilityService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    /**
     * Grabs the remote's assistant / mic button before the Google Assistant gets it
     * and opens Jarvis instead.
     */
    override fun onKeyEvent(event: KeyEvent): Boolean {
        val code = event.keyCode
        if (code == KeyEvent.KEYCODE_ASSIST ||
            code == KeyEvent.KEYCODE_VOICE_ASSIST ||
            code == KeyEvent.KEYCODE_SEARCH
        ) {
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                AssistantService.trigger(applicationContext)
            }
            return true
        }
        return false
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    fun global(action: Int): Boolean = performGlobalAction(action)

    // ---------- navigation ----------

    private fun focusedNode(): AccessibilityNodeInfo? {
        val root = rootInActiveWindow ?: return null
        return root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
            ?: root.findFocus(AccessibilityNodeInfo.FOCUS_ACCESSIBILITY)
    }

    private fun firstFocusable(n: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (n.isFocusable && n.isVisibleToUser) return n
        for (i in 0 until n.childCount) {
            val c = n.getChild(i) ?: continue
            val found = firstFocusable(c)
            if (found != null) return found
        }
        return null
    }

    /** direction is one of View.FOCUS_UP / DOWN / LEFT / RIGHT */
    fun moveFocus(direction: Int): Boolean {
        val root = rootInActiveWindow ?: return false
        val current = focusedNode()
        val target = if (current != null) current.focusSearch(direction) else firstFocusable(root)
        return target?.performAction(AccessibilityNodeInfo.ACTION_FOCUS) ?: false
    }

    private fun clickNode(start: AccessibilityNodeInfo?): Boolean {
        var cur = start
        var depth = 0
        while (cur != null && depth < 8) {
            if (cur.isClickable && cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            cur = cur.parent
            depth++
        }
        return start?.performAction(AccessibilityNodeInfo.ACTION_CLICK) ?: false
    }

    /** Presses OK on whatever is focused. */
    fun select(): Boolean = clickNode(focusedNode())

    fun clickText(text: String): Boolean {
        if (text.isBlank()) return false
        val root = rootInActiveWindow ?: return false
        val matches = root.findAccessibilityNodeInfosByText(text)
        if (matches.isNullOrEmpty()) return false
        val exact = matches.firstOrNull {
            it.isVisibleToUser && (
                it.text?.toString().equals(text, ignoreCase = true) ||
                    it.contentDescription?.toString().equals(text, ignoreCase = true)
                )
        }
        val pick = exact ?: matches.firstOrNull { it.isVisibleToUser } ?: matches.first()
        if (clickNode(pick)) return true
        // some TV items only react to focus + select
        return pick.performAction(AccessibilityNodeInfo.ACTION_FOCUS) && select()
    }

    private fun findScrollable(n: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (n.isScrollable && n.isVisibleToUser) return n
        for (i in 0 until n.childCount) {
            val c = n.getChild(i) ?: continue
            val found = findScrollable(c)
            if (found != null) return found
        }
        return null
    }

    fun scroll(forward: Boolean): Boolean {
        val root = rootInActiveWindow ?: return false
        val node = findScrollable(root) ?: return false
        val action = if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
        else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        return node.performAction(action)
    }

    private fun findEditable(n: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (n.isEditable && n.isVisibleToUser) return n
        for (i in 0 until n.childCount) {
            val c = n.getChild(i) ?: continue
            val found = findEditable(c)
            if (found != null) return found
        }
        return null
    }

    fun setText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val focused = focusedNode()
        val node = if (focused != null && focused.isEditable) focused else findEditable(root)
        if (node == null) return false
        val args = Bundle()
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    // ---------- seeing the screen ----------

    /** All visible text on screen. Handy when a screenshot comes back black (protected video). */
    fun screenText(): String {
        val root = rootInActiveWindow ?: return ""
        val seen = LinkedHashSet<String>()
        fun walk(n: AccessibilityNodeInfo, depth: Int) {
            if (depth > 40 || seen.size > 120) return
            if (n.isVisibleToUser) {
                val t = n.text?.toString()?.trim()
                val d = n.contentDescription?.toString()?.trim()
                if (!t.isNullOrEmpty()) seen.add(t)
                if (!d.isNullOrEmpty()) seen.add(d)
            }
            for (i in 0 until n.childCount) {
                val c = n.getChild(i) ?: continue
                walk(c, depth + 1)
            }
        }
        walk(root, 0)
        return seen.joinToString(" | ").take(2500)
    }

    /** Takes a screenshot (Android 11+) and returns it as a small JPEG, or null if it was not possible. */
    fun screenshotJpeg(): ByteArray? {
        if (Build.VERSION.SDK_INT < 30) return null
        val latch = CountDownLatch(1)
        var out: ByteArray? = null
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : AccessibilityService.TakeScreenshotCallback {
            override fun onSuccess(result: AccessibilityService.ScreenshotResult) {
                try {
                    val hw = Bitmap.wrapHardwareBuffer(result.hardwareBuffer, result.colorSpace)
                    if (hw != null) {
                        val soft = hw.copy(Bitmap.Config.ARGB_8888, false)
                        val scale = min(1f, 1024f / max(soft.width, soft.height).toFloat())
                        val bmp = if (scale < 1f) {
                            Bitmap.createScaledBitmap(
                                soft,
                                (soft.width * scale).toInt(),
                                (soft.height * scale).toInt(),
                                true
                            )
                        } else soft
                        val bos = ByteArrayOutputStream()
                        bmp.compress(Bitmap.CompressFormat.JPEG, 70, bos)
                        out = bos.toByteArray()
                    }
                } catch (ignored: Exception) {
                } finally {
                    try {
                        result.hardwareBuffer.close()
                    } catch (ignored: Exception) {
                    }
                    latch.countDown()
                }
            }

            override fun onFailure(errorCode: Int) {
                latch.countDown()
            }
        })
        latch.await(6, TimeUnit.SECONDS)
        return out
    }
}
