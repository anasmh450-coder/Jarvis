package com.myassistant.tv

import android.Manifest
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** Simple setup screen: permissions, a connection test and the Start / Stop button. */
class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var testOut: TextView
    private lateinit var startBtn: Button
    private var keyBox: EditText? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun pill(fill: Int, stroke: Int) = GradientDrawable().apply {
        cornerRadius = dp(28).toFloat()
        setColor(fill)
        if (stroke != 0) setStroke(dp(3), stroke)
    }

    /** heightDp = 0 means wrap content; top margin is in dp too. */
    private fun lp(heightDp: Int = 0, top: Int = 0) =
        LinearLayout.LayoutParams(
            dp(560),
            if (heightDp == 0) ViewGroup.LayoutParams.WRAP_CONTENT else dp(heightDp)
        ).apply { topMargin = dp(top) }

    private fun label(text: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(color)
        gravity = Gravity.CENTER_HORIZONTAL
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun button(text: String, onClick: () -> Unit) = Button(this).apply {
        this.text = text
        isAllCaps = false
        textSize = 18f
        setTextColor(Color.WHITE)
        isFocusable = true
        background = pill(0xFF1D1D33.toInt(), 0)
        setOnFocusChangeListener { v, focused ->
            v.background = pill(
                if (focused) 0xFF3A2F8F.toInt() else 0xFF1D1D33.toInt(),
                if (focused) 0xFF58C7FF.toInt() else 0
            )
        }
        setOnClickListener { onClick() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val scroll = ScrollView(this).apply {
            setBackgroundColor(0xFF0B0B14.toInt())
            isFillViewport = true
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(24), dp(24), dp(24), dp(40))
        }
        scroll.addView(col, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        col.addView(OrbView(this), LinearLayout.LayoutParams(dp(150), dp(150)))
        col.addView(label("Jarvis", 38f, Color.WHITE, true), lp())
        col.addView(label("Say \"Jarvis\" and ask anything, or tell him to control the TV", 16f, 0xFF9AA0B8.toInt()), lp(top = 4))

        status = label("", 18f, Color.WHITE).apply { gravity = Gravity.START }
        col.addView(status, lp(top = 22))

        if (!Config.hasBuiltInKey()) {
            val box = EditText(this).apply {
                hint = "Paste your Gemini API key"
                setHintTextColor(0xFF6B7090.toInt())
                setTextColor(Color.WHITE)
                inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                setSingleLine(true)
            }
            keyBox = box
            col.addView(box, lp(top = 12))
            col.addView(button("Save key") {
                Config.saveApiKey(this, box.text.toString())
                Toast.makeText(this, "Key saved", Toast.LENGTH_SHORT).show()
            }, lp(56, 8))
        }

        col.addView(button("1. Allow microphone") { askMic() }, lp(56, 10))
        col.addView(button("2. Allow floating orb (overlay)") { askOverlay() }, lp(56, 10))
        col.addView(button("3. Enable TV control (accessibility)") { askAccessibility() }, lp(56, 10))
        col.addView(button("4. Use Jarvis on the Assistant button") { askAssistant() }, lp(56, 10))
        col.addView(button("Test AI connection") { testAi() }, lp(56, 10))
        startBtn = button("Start Jarvis") { toggle() }
        col.addView(startBtn, lp(56, 10))

        testOut = label("", 14f, 0xFFB7BCD6.toInt())
        col.addView(testOut, lp(top = 12))

        val adb = "No settings screen on your TV? Use adb from a computer:\n" +
            "adb shell pm grant $packageName android.permission.RECORD_AUDIO\n" +
            "adb shell appops set $packageName SYSTEM_ALERT_WINDOW allow\n" +
            "adb shell settings put secure enabled_accessibility_services $packageName/$packageName.TvAccessibilityService\n" +
            "adb shell settings put secure accessibility_enabled 1\n" +
            "Optional, to also make Jarvis the system assistant:\n" +
            "adb shell settings put secure assistant $packageName/$packageName.JarvisInteractionService\n" +
            "adb shell settings put secure voice_interaction_service $packageName/$packageName.JarvisInteractionService"
        col.addView(label(adb, 11f, 0xFF6B7090.toInt()).apply { gravity = Gravity.START }, lp(top = 22))

        setContentView(scroll)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun micOk() = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
    private fun overlayOk() = Settings.canDrawOverlays(this)
    private fun a11yOk(): Boolean {
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
        return enabled.contains(packageName)
    }

    private fun refresh() {
        fun mark(ok: Boolean) = if (ok) "✓" else "✗"
        status.text = "${mark(micOk())}  Microphone\n" +
            "${mark(overlayOk())}  Floating orb (overlay)\n" +
            "${mark(a11yOk())}  TV control (accessibility)\n" +
            "${mark(Config.apiKey(this).isNotBlank())}  Gemini key"
        startBtn.text = if (AssistantService.running) "Stop Jarvis" else "Start Jarvis"
    }

    private fun askMic() {
        val perms = if (Build.VERSION.SDK_INT >= 33)
            arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS)
        else arrayOf(Manifest.permission.RECORD_AUDIO)
        requestPermissions(perms, 1)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refresh()
    }

    private fun askOverlay() {
        try {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        } catch (ignored: ActivityNotFoundException) {
            Toast.makeText(this, "Not available on this TV. Use the adb command below.", Toast.LENGTH_LONG).show()
        }
    }

    private fun askAccessibility() {
        try {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        } catch (ignored: ActivityNotFoundException) {
            Toast.makeText(this, "Not available on this TV. Use the adb command below.", Toast.LENGTH_LONG).show()
        }
    }

    private fun askAssistant() {
        val tries = listOf(
            Settings.ACTION_VOICE_INPUT_SETTINGS,
            Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS
        )
        for (action in tries) {
            try {
                startActivity(Intent(action))
                Toast.makeText(this, "Choose Jarvis as the assistant", Toast.LENGTH_LONG).show()
                return
            } catch (ignored: ActivityNotFoundException) {
            }
        }
        Toast.makeText(
            this,
            "Not available on this TV. Step 3 already catches the Assistant button; or use the adb commands below.",
            Toast.LENGTH_LONG
        ).show()
    }

    private fun testAi() {
        keyBox?.let { if (it.text.isNotBlank()) Config.saveApiKey(this, it.text.toString()) }
        val key = Config.apiKey(this)
        if (key.isBlank()) {
            testOut.text = "No Gemini key yet."
            return
        }
        testOut.text = "Testing..."
        Thread {
            val result = try {
                val contents = org.json.JSONArray().put(GeminiClient.textTurn("user", "Say hello in one short sentence and confirm you work."))
                "OK: " + GeminiClient.generate(key, "You are a friendly assistant.", contents, useSearch = false).trim()
            } catch (e: Exception) {
                "ERROR: " + (e.message ?: e.javaClass.simpleName)
            }
            runOnUiThread { testOut.text = result }
        }.start()
    }

    private fun toggle() {
        if (AssistantService.running) {
            stopService(Intent(this, AssistantService::class.java))
            AssistantService.running = false
            refresh()
            return
        }
        if (!micOk()) {
            askMic()
            return
        }
        if (!overlayOk()) {
            Toast.makeText(this, "The floating orb needs the overlay permission", Toast.LENGTH_LONG).show()
        }
        startForegroundService(Intent(this, AssistantService::class.java))
        startBtn.postDelayed({ refresh() }, 600)
    }
}
