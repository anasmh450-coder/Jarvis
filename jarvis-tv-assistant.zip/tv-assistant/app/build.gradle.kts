plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.myassistant.tv"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.myassistant.tv"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        // The Gemini key is NOT stored in the source code.
        // It comes from the GEMINI_API_KEY environment variable (GitHub secret) or a gradle property.
        // If it is empty, the app lets you paste the key on screen instead.
        val geminiKey = (project.findProperty("GEMINI_API_KEY") as String?)
            ?: System.getenv("GEMINI_API_KEY")
            ?: ""
        buildConfigField("String", "GEMINI_API_KEY", "\"${geminiKey.trim()}\"")
    }

    buildFeatures {
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
}
